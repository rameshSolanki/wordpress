     <div class="breadcrumbs" typeof="BreadcrumbList" vocab="https://schema.org/">
    <?php
    if (function_exists('bcn_display')) {
            bcn_display();
    }?>
</div>
