
                <?php //the_post(); ?>
                <?php //get_template_part('content', 'page'); ?>
                 
                <?php //comments_template('', true); ?>
                 
           <!-- end home-page-content -->
             
          
                <?php
                $category_id = get_cat_ID('code');
                $catquery = new WP_Query('cat=' .$category_id. '&posts_per_page=5');
                while ($catquery->have_posts()) :
                    $catquery->the_post();
                    ?>
                <h2><?php //the_title(); ?></h2>
                 
                    <?php //the_content(); ?>
                  <a href="<?php the_permalink();?>"><?php the_title(); ?></a>
                    <?php echo '<hr/>'; ?>
                <?php endwhile; ?>
                                 
    <?php //comments_template('', true); ?>
                 
           <!-- end home-post-content -->




          